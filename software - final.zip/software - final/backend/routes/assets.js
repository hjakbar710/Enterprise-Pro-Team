const express = require("express");
const db = require("../db");

const router = express.Router();

function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).send("Not logged in");
  }
  next();
}

router.get("/", requireLogin, (req, res) => {
  const sql = `
    SELECT
      assets.id,
      assets.ratepayer,
      assets.address,
      assets.postcode,
      assets.latitude,
      assets.longitude,
      assets.rateable_value,
      assets.job_count,
      assets.uploaded_by,
      assets.created_at,
      categories.name AS category
    FROM assets
    LEFT JOIN categories
    ON assets.category_id = categories.id
    ORDER BY assets.id DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send("Database error");
      return;
    }

    res.json(results);
  });
});

router.post("/", requireLogin, (req, res) => {
  const {
    ratepayer,
    address,
    postcode,
    latitude,
    longitude,
    rateable_value
  } = req.body;

  const sql = `
    INSERT INTO assets
    (ratepayer, address, postcode, latitude, longitude, rateable_value, uploaded_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    sql,
    [
      ratepayer,
      address,
      postcode,
      latitude,
      longitude,
      rateable_value,
      req.session.userId
    ],
    (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send("Insert failed");
        return;
      }

      res.json({
        message: "Asset added",
        id: result.insertId
      });
    }
  );
});

router.post("/:id/job", requireLogin, (req, res) => {
  const assetId = req.params.id;
  const { job_type, notes } = req.body;

  const sql = `
    INSERT INTO jobs (asset_id, job_type, notes)
    VALUES (?, ?, ?)
  `;

  db.query(sql, [assetId, job_type, notes], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Job insert failed");
      return;
    }

    const updateSql = `
      UPDATE assets
      SET job_count = job_count + 1
      WHERE id = ?
    `;

    db.query(updateSql, [assetId]);

    res.json({ message: "Job logged" });
  });
});

module.exports = router;