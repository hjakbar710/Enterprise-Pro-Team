const express = require("express");
const multer = require("multer");
const csv = require("csv-parser");
const fs = require("fs");
const db = require("../db");

const router = express.Router();
const upload = multer({ dest: "uploads/" });

function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).send("Not logged in");
  }
  next();
}

function sanitiseColumnName(name) {
  return String(name)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "");
}

function getExistingColumns() {
  return new Promise((resolve, reject) => {
    db.query("SHOW COLUMNS FROM assets", (err, results) => {
      if (err) return reject(err);
      resolve(results.map(col => col.Field));
    });
  });
}

function addMissingColumns(missingColumns) {
  return new Promise((resolve, reject) => {
    if (missingColumns.length === 0) return resolve();

    const alterParts = missingColumns.map(
      col => `ADD COLUMN \`${col}\` TEXT NULL`
    );

    db.query(`ALTER TABLE assets ${alterParts.join(", ")}`, (err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

router.post("/", requireLogin, upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No file uploaded");
  }

  const rows = [];
  let rawHeaders = [];

  fs.createReadStream(req.file.path)
    .pipe(csv())
    .on("headers", (headers) => {
      rawHeaders = headers;
    })
    .on("data", (row) => {
      rows.push(row);
    })
    .on("end", async () => {
      try {
        if (rows.length === 0) {
          fs.unlinkSync(req.file.path);
          return res.status(400).send("CSV file is empty");
        }

        const csvColumnMap = {};
        rawHeaders.forEach(header => {
          const safe = sanitiseColumnName(header);
          if (safe) csvColumnMap[header] = safe;
        });

        const existingColumns = await getExistingColumns();

        const missingColumns = Object.values(csvColumnMap).filter(
          col => !existingColumns.includes(col)
        );

        await addMissingColumns(missingColumns);

        let inserted = 0;
        let skipped = 0;

        const insertNext = (index) => {
          if (index >= rows.length) {
            if (fs.existsSync(req.file.path)) {
              fs.unlinkSync(req.file.path);
            }

            return res.json({
              message: "CSV uploaded successfully",
              inserted,
              skipped,
              addedColumns: missingColumns
            });
          }

          const originalRow = rows[index];
          const cleanedRow = {};

          Object.keys(originalRow).forEach((key) => {
            const safeKey = csvColumnMap[key];
            if (safeKey) {
              let value = originalRow[key];
              if (typeof value === "string") value = value.trim();
              cleanedRow[safeKey] = value === "" ? null : value;
            }
          });

          cleanedRow.uploaded_by = req.session.userId;

          const columns = Object.keys(cleanedRow).filter(col => col !== "id");
          if (columns.length === 0) {
            skipped++;
            return insertNext(index + 1);
          }

          const values = columns.map(col => cleanedRow[col]);
          const placeholders = columns.map(() => "?").join(", ");
          const escapedColumns = columns.map(col => `\`${col}\``).join(", ");

          const sql = `
            INSERT INTO assets (${escapedColumns})
            VALUES (${placeholders})
          `;

          db.query(sql, values, (err) => {
            if (err) {
              console.error("Row insert failed:", err.sqlMessage || err.message);
              skipped++;
            } else {
              inserted++;
            }

            insertNext(index + 1);
          });
        };

        insertNext(0);
      } catch (error) {
        console.error("Upload processing failed:", error);

        if (fs.existsSync(req.file.path)) {
          fs.unlinkSync(req.file.path);
        }

        res.status(500).json({ error: error.message });
      }
    })
    .on("error", (err) => {
      console.error("CSV read failed:", err);

      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }

      res.status(500).send("Failed to process CSV");
    });
});

module.exports = router;