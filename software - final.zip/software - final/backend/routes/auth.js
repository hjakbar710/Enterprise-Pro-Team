const express = require("express");
const bcrypt = require("bcrypt");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const db = require("../db");

const router = express.Router();

/* -----------------------------
   EMAIL CONFIG
------------------------------*/
const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: "qadeera040@gmail.com",
    pass: "sunj upoa kaza gpik"
  }
});

/* -----------------------------
   PASSWORD VALIDATION
------------------------------*/
function isValidPassword(password) {
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
  return passwordRegex.test(password);
}

/* -----------------------------
   REGISTER + EMAIL VERIFICATION
------------------------------*/
router.post("/register", async (req, res) => {
  const { username, email, password } = req.body;

  if (!isValidPassword(password)) {
    return res.status(400).send(
      "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number."
    );
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const verificationToken = crypto.randomBytes(32).toString("hex");

  const sql = `
    INSERT INTO users (username, email, password, role, is_verified, verification_token)
    VALUES (?, ?, ?, 'user', 0, ?)
  `;

  db.query(sql, [username, email, hashedPassword, verificationToken], async (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Registration failed");
    }

    const verifyLink = `http://localhost:3000/auth/verify-email?token=${verificationToken}`;

    try {
      await transporter.sendMail({
        from: '"Bradford Asset System" <qadeera040@gmail.com>',
        to: email,
        subject: "Verify your email address",
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color:#2c3e50;">Verify your email</h2>
            <p>Thank you for creating an account for the Bradford Asset System.</p>
            <p>Please click the button below to verify your email and activate your account:</p>
            <p>
              <a href="${verifyLink}" style="display:inline-block;padding:12px 18px;background:#2c3e50;color:white;text-decoration:none;border-radius:8px;">
                Verify Email
              </a>
            </p>
            <p>If you did not create this account, you can ignore this email.</p>
          </div>
        `
      });

      res.json({
        message: "Registration successful. Please check your email to verify your account before logging in."
      });
    } catch (mailErr) {
      console.error(mailErr);
      res.status(500).send("Account created, but failed to send verification email");
    }
  });
});

/* -----------------------------
   VERIFY EMAIL
------------------------------*/
router.get("/verify-email", (req, res) => {
  const { token } = req.query;

  if (!token) {
    return res.status(400).send("Invalid verification link");
  }

  db.query(
    "SELECT * FROM users WHERE verification_token = ? LIMIT 1",
    [token],
    (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      if (results.length === 0) {
        return res.status(400).send("Invalid or expired verification link");
      }

      const user = results[0];

      db.query(
        "UPDATE users SET is_verified = 1, verification_token = NULL WHERE id = ?",
        [user.id],
        (updateErr) => {
          if (updateErr) {
            console.error(updateErr);
            return res.status(500).send("Failed to verify account");
          }

          res.redirect("/login.html?verified=1");
        }
      );
    }
  );
});

/* -----------------------------
   LOGIN
------------------------------*/
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Login failed");
    }

    if (results.length === 0) {
      return res.status(401).send("User not found");
    }

    const user = results[0];

    if (!user.is_verified) {
      return res.status(403).send("Please verify your email before logging in.");
    }

    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return res.status(401).send("Incorrect password");
    }

    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.username = user.username;

    req.session.save(() => {
      res.json({
        message: "Login successful",
        role: user.role
      });
    });
  });
});

/* -----------------------------
   CHECK SESSION
------------------------------*/
router.get("/check", (req, res) => {
  if (req.session.userId) {
    res.json({
      loggedIn: true,
      userId: req.session.userId,
      username: req.session.username,
      role: req.session.role
    });
  } else {
    res.status(401).json({ loggedIn: false });
  }
});

/* -----------------------------
   LOGOUT
------------------------------*/
router.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ message: "Logged out" });
  });
});

/* -----------------------------
   FORGOT PASSWORD
------------------------------*/
router.post("/forgot-password", (req, res) => {
  const { email } = req.body;

  db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }

    if (results.length === 0) {
      return res.json({
        message: "If that email exists, a reset link has been sent."
      });
    }

    const user = results[0];
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    db.query("DELETE FROM password_resets WHERE user_id = ?", [user.id], (deleteErr) => {
      if (deleteErr) {
        console.error(deleteErr);
        return res.status(500).send("Database error");
      }

      db.query(
        "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
        [user.id, token, expiresAt],
        async (insertErr) => {
          if (insertErr) {
            console.error(insertErr);
            return res.status(500).send("Database error");
          }

          const resetLink = `http://localhost:3000/reset-password.html?token=${token}`;

          try {
            await transporter.sendMail({
              from: '"Bradford Asset System" <qadeera040@gmail.com>',
              to: user.email,
              subject: "Reset your password",
              html: `
                <div style="font-family: Arial, sans-serif; padding: 20px;">
                  <h2 style="color:#2c3e50;">Reset your password</h2>
                  <p>You requested a password reset for the Bradford Asset System.</p>
                  <p>Click the button below to choose a new password:</p>
                  <p>
                    <a href="${resetLink}" style="display:inline-block;padding:12px 18px;background:#2c3e50;color:white;text-decoration:none;border-radius:8px;">
                      Reset Password
                    </a>
                  </p>
                  <p>This link expires in 1 hour.</p>
                </div>
              `
            });

            res.json({
              message: "If that email exists, a reset link has been sent."
            });
          } catch (mailErr) {
            console.error(mailErr);
            res.status(500).send("Failed to send email");
          }
        }
      );
    });
  });
});

/* -----------------------------
   RESET PASSWORD
------------------------------*/
router.post("/reset-password", async (req, res) => {
  const { token, password } = req.body;

  if (!token || !password) {
    return res.status(400).send("Missing token or password");
  }

  if (!isValidPassword(password)) {
    return res.status(400).send(
      "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number."
    );
  }

  db.query(
    "SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1",
    [token],
    async (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      if (results.length === 0) {
        return res.status(400).send("Invalid or expired reset token");
      }

      const resetRecord = results[0];
      const hashedPassword = await bcrypt.hash(password, 10);

      db.query(
        "UPDATE users SET password = ? WHERE id = ?",
        [hashedPassword, resetRecord.user_id],
        (updateErr) => {
          if (updateErr) {
            console.error(updateErr);
            return res.status(500).send("Failed to update password");
          }

          db.query(
            "DELETE FROM password_resets WHERE user_id = ?",
            [resetRecord.user_id],
            () => {
              res.json({ message: "Password reset successfully" });
            }
          );
        }
      );
    }
  );
});

module.exports = router;