const express = require("express");
const db = require("../db");

const router = express.Router();

function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).send("Not logged in");
  }
  next();
}

function requireAdmin(req, res, next) {
  if (req.session.role !== "admin") {
    return res.status(403).send("Admin access only");
  }
  next();
}

/* -----------------------------
   ADMIN SUMMARY
------------------------------*/
router.get("/summary", requireLogin, requireAdmin, (req, res) => {
  const summary = {};

  db.query("SELECT COUNT(*) AS totalUsers FROM users", (err, userResults) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }

    summary.totalUsers = userResults[0].totalUsers;

    db.query("SELECT COUNT(*) AS totalAssets FROM assets", (err, assetResults) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      summary.totalAssets = assetResults[0].totalAssets;

      db.query(
        "SELECT COUNT(*) AS newUsers FROM users WHERE created_at >= NOW() - INTERVAL 1 DAY",
        (err, newUserResults) => {
          if (err) {
            console.error(err);
            return res.status(500).send("Database error");
          }

          summary.newUsers = newUserResults[0].newUsers;

          db.query(
            "SELECT COUNT(*) AS newAssets FROM assets WHERE created_at >= NOW() - INTERVAL 1 DAY",
            (err, newAssetResults) => {
              if (err) {
                console.error(err);
                return res.status(500).send("Database error");
              }

              summary.newAssets = newAssetResults[0].newAssets;

              res.json(summary);
            }
          );
        }
      );
    });
  });
});

/* -----------------------------
   GET ALL USERS
------------------------------*/
router.get("/users", requireLogin, requireAdmin, (req, res) => {
  const sql = `
    SELECT id, username, email, role, created_at
    FROM users
    ORDER BY id DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }

    res.json(results);
  });
});

/* -----------------------------
   UPDATE USER
------------------------------*/
router.put("/users/:id", requireLogin, requireAdmin, (req, res) => {
  const userId = req.params.id;
  const { username, email, role } = req.body;

  if (!username || !email || !role) {
    return res.status(400).send("Missing required fields");
  }

  if (role !== "user" && role !== "admin") {
    return res.status(400).send("Invalid role");
  }

  const sql = `
    UPDATE users
    SET username = ?, email = ?, role = ?
    WHERE id = ?
  `;

  db.query(sql, [username, email, role, userId], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Failed to update user");
    }

    res.json({ message: "User updated successfully" });
  });
});

/* -----------------------------
   DELETE USER
------------------------------*/
router.delete("/users/:id", requireLogin, requireAdmin, (req, res) => {
  const userId = req.params.id;

  if (String(userId) === String(req.session.userId)) {
    return res.status(400).send("You cannot delete your own admin account");
  }

  db.query("DELETE FROM users WHERE id = ?", [userId], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Failed to delete user");
    }

    res.json({ message: "User deleted" });
  });
});

/* -----------------------------
   GET ALL ASSETS
------------------------------*/
router.get("/assets", requireLogin, requireAdmin, (req, res) => {
  const sql = `
    SELECT
      id,
      ratepayer,
      address,
      postcode,
      latitude,
      longitude,
      rateable_value,
      uploaded_by,
      created_at
    FROM assets
    ORDER BY id DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }

    res.json(results);
  });
});

/* -----------------------------
   DELETE ASSET
------------------------------*/
router.delete("/assets/:id", requireLogin, requireAdmin, (req, res) => {
  const assetId = req.params.id;

  db.query("DELETE FROM assets WHERE id = ?", [assetId], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Failed to delete asset");
    }

    res.json({ message: "Asset deleted" });
  });
});

module.exports = router;