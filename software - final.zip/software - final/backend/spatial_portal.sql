-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2026 at 04:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spatial_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `ratepayer` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `rateable_value` int(11) DEFAULT NULL,
  `job_count` int(11) DEFAULT 0,
  `category_id` int(11) DEFAULT NULL,
  `owner_name` text DEFAULT NULL,
  `asset_status` text DEFAULT NULL,
  `inspection_date` text DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `ratepayer`, `address`, `postcode`, `latitude`, `longitude`, `rateable_value`, `job_count`, `category_id`, `owner_name`, `asset_status`, `inspection_date`, `uploaded_by`, `created_at`) VALUES
(1, 'A1 Tyres', 'Kensington Street, Keighley, BD21 1PW', 'BD21 1PW', 53.8629000, -1.9162500, 3900, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(2, 'St John The Evangelist Academy', 'St John Rc First School, Beacon Road, Bradford, BD6 3DQ', 'BD6 3DQ', 53.7708400, -1.8014600, 25250, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(3, 'Kehoe\'S Limited', 'The Venue, Park Lane, Bradford, BD5 0JL', 'BD5 0JL', 53.7845300, -1.7591500, 6250, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(4, 'Unit Q', 'Blackshaw Mills, Halifax Road, Bradford, BD6 2HL', 'BD6 2HL', 53.7575700, -1.8009900, 4250, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(5, 'Crossflatts Old People Association', 'Community Centre, St Aidans Square, Crossflatts, Bingley, BD16 2BN', 'BD16 2BN', 53.8613900, -1.8445800, 2800, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(6, 'Bingley Chamber Of Trade And Commerce', 'Store, Queens Court, Bingley, BD16 2LT', 'BD16 2LT', 53.8485000, -1.8390200, 1475, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(7, 'Stables Rear Of', '62, Branksome Drive, Shipley, BD18 4BE', 'BD18 4BE', 53.8364300, -1.8115900, 900, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(8, 'Cobley And Cockshott Ltd', '19, Bridge Street, Keighley, BD21 1AA', 'BD21 1AA', 53.8650800, -1.9107100, 3550, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(9, 'The Bank', 'Cleasby Road, Menston, Ilkley, LS29 6JE', 'LS29 6JE', 53.8908900, -1.7356200, 3200, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(10, 'Santander Uk Plc', 'Abbey National, 9, Nelson Street, Bradford, BD1 5AN', 'BD1 5AN', 53.7903700, -1.7513600, 985000, 0, 1, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(11, 'Bardsley Powell Estates', '4a, Little Horton Green, Bradford, BD5 0NG', 'BD5 0NG', 53.7849300, -1.7650300, 1400, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(12, 'Salem Athletic Cricket Club', 'Sports Ground, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', 53.8135700, -1.7915900, 5900, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(13, 'Lalas', '55, Toller Lane, Bradford, BD8 9DD', 'BD8 9DD', 53.8046800, -1.7798500, 50500, 1, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(14, 'Empire House Piccadilly Limited', '8-10, Piccadilly, Bradford, BD1 3LS', 'BD1 3LS', 53.7955800, -1.7533500, 0, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(15, 'Storage', '1st Floor, Drill Parade, Bradford, BD8 7HY', 'BD8 7HY', 53.8029400, -1.7621000, 0, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(16, 'Tsb Banking Group Plc', '74-76, Towngate, Keighley, BD21 3QE', 'BD21 3QE', 53.8675700, -1.9072700, 53000, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(17, 'Clifton Mill', 'Upper Ground Floor, Clifton Street, Bradford, BD8 7DA', 'BD8 7DA', 53.8057100, -1.7626300, 8500, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(18, 'Hbcl Coldstores Limited', 'Unit 9, G B Business Park, Cutler Heights Lane, Bradford, BD4 9HZ', 'BD4 9HZ', 53.7812500, -1.7162900, 29000, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(19, 'Tote Bookmakers Limited', '228, High Street, Wibsey, Bradford, BD6 1QP', 'BD6 1QP', 53.7669300, -1.7743900, 7600, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(20, 'The Congregational Federation Limited', '405, Thornton Road, Thornton, Bradford, BD13 3JN', 'BD13 3JN', 53.7904600, -1.8536200, 4650, 0, 2, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(21, 'The Secretary Northcliffe Golf Club', 'Northcliffe Golf Course, High Bank Lane, Shipley, BD18 4LJ', 'BD18 4LJ', 53.8286600, -1.7980100, 42750, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(22, 'S&M Kirkgate Limited', '6, Piccadilly, Bradford, BD1 3LW', 'BD1 3LW', 53.7951500, -1.7528300, 12500, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(23, 'Mahmoods (Franchising) Limited', 'Unit 2, Red Oak House, Duncombe Street, Bradford, BD8 9AJ', 'BD8 9AJ', 53.7967900, -1.7816700, 18500, 1, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(24, 'Penyffordd Pharmacy Limited', '238, Whetley Lane, Bradford, BD8 9DJ', 'BD8 9DJ', 53.8034100, -1.7762400, 6600, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(25, 'The Upstagers Theatre Charity Limited', 'Unit 6, 1st Floor, Booths Yard, Nile Road, Ilkley, LS29 8HJ', 'LS29 8HJ', 53.9258100, -1.8217800, 4750, 1, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(26, 'Primesight Limited', 'Advert Rights No 1344 02-06, Baildon Bridge, Otley Road, Baildon, BD17 7ER', 'BD17 7ER', 53.8381500, -1.7724100, 8000, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(27, 'Lodge Of The Three Graces No 408', 'Masonic Hall Opp, Police Station, Mill Hey, Haworth, Keighley, BD22 8NA', 'BD22 8NA', 53.8323600, -1.9467200, 5900, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(28, 'Co-Operative Group Limited', 'Shop, 24, Station Road, Oxenhope, Keighley, BD22 9JJ', 'BD22 9JJ', 53.8110000, -1.9509200, 27000, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(29, 'Raiseprint Limited', 'Unit E1-2, Royd Ings Avenue, Keighley, BD21 3QY', 'BD21 3QY', 53.8660700, -1.9072000, 42750, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(30, 'Edwick Memorial Hall Trust Limited', 'The Birches, Otley Road, Eldwick, Bingley, BD16 3EQ', 'BD16 3EQ', 53.8602900, -1.8127500, 4300, 0, 3, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(31, 'The Childrens Place Limited', 'Creche, 83, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', 53.8135700, -1.7915900, 16500, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(32, 'Empire House Piccadilly Limited', '3rd Floor, 8-10, Piccadilly, Bradford, BD1 3LS', 'BD1 3LS', 53.7955800, -1.7533500, 18500, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(33, 'Sofa Doctor Ltd', '103, Legrams Lane, Bradford, BD7 2AA', 'BD7 2AA', 53.7911700, -1.7790700, 5600, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(34, 'Co-Operative Group Limited', '6, Tyrrel Street, Bradford, BD1 1RJ', 'BD1 1RJ', 53.7938500, -1.7536400, 31000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(35, 'Car Parking Bay', 'No 19, West Riding House, Cheapside, Bradford, BD1 4HR', 'BD1 4HR', 53.7956100, -1.7525700, 600, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(36, 'Warehouse And Premises', 'Worth Way, Keighley, BD21 5AJ', 'BD21 5AJ', 53.8652300, -1.9061900, 17250, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(37, 'Shorts Industries Limited', '6, Station Road, Canal Rd-Queens Rd, Bradford, BD1 4SF', 'BD1 4SF', 53.8090300, -1.7573700, 71000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(38, 'Babycare (Bradford) Limited', 'Unit 1, Oxford Works, Dudley Hill Road, Bradford, BD2 3AA', 'BD2 3AA', 53.8094900, -1.7302900, 11250, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(39, 'The Secretary Keighley Golf Club', 'Keighley Golf Club, Howden Park, Silsden, BD20 6DH', 'BD20 6DH', 53.8876800, -1.9165800, 57000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(40, 'Bellissimo Workspace Limited', 'Unit 31, Dalton Mills, Dalton Lane, Keighley, BD21 4JH', 'BD21 4JH', 53.8692200, -1.8943900, 1350, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(41, 'Mectec', 'Ingrow Bridge, South Street, Keighley, BD21 5AX', 'BD21 5AX', 53.8545400, -1.9157300, 7600, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(42, 'Keighley & Worth Valley Railway Preservation Society Limited', 'Keighley And, Worth Valley Railway, Station Road, Haworth, Keighley, BD22 8NJ', 'BD22 8NJ', 53.8312200, -1.9487300, 100000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(43, 'Tunnacliffe & Lambert Limited', '18, Station Road, Clayton, Bradford, BD14 6JA', 'BD14 6JA', 53.7815400, -1.8182600, 6000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(44, 'Medical Centre', '81, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', 53.8135700, -1.7915900, 45000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(45, 'The Governing Body', 'Sandy Lane Primary School, Cottingley Road, Bradford, BD15 9JU', 'BD15 9JU', 53.8169500, -1.8319400, 48000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(46, 'Priestley & Webb Ltd', '318, Keighley Road, Bradford, BD9 4EX', 'BD9 4EX', 53.8201600, -1.7744800, 5000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(47, 'Central Motor Company', '129, Great Horton Road, Bradford, BD7 1QG', 'BD7 1QG', 53.7881300, -1.7698700, 14000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(48, 'Myers Building Supplies Ltd', 'Old Cornmill, Keighley Road, Silsden, BD20 0DY', 'BD20 0DY', 53.9102800, -1.9385200, 54000, 0, 4, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(49, 'Hussain\'s', '64 aloo ave', 'BD6 2LO', 53.7818206, -1.7671985, 2000, 0, NULL, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(50, 'Test Shop', '10 Market Street', 'BD1 1AA', 53.7961000, -1.7594000, 12000, 0, NULL, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(51, 'City Office', '20 Main Road', 'BD1 2BB', 53.7980000, -1.7520000, 18000, 0, NULL, NULL, NULL, NULL, NULL, '2026-04-15 10:54:55'),
(52, 'Bradford Test Retail', '10 Market Street', 'BD1 1AA', 53.7961000, -1.7594000, 12000, 0, NULL, 'Bradford Council', 'Active', '2026-04-10', NULL, '2026-04-15 10:54:55'),
(53, 'City Office Demo', '20 Main Road', 'BD1 2BB', 53.7980000, -1.7520000, 18000, 0, NULL, 'Private Owner', 'Needs Review', '2026-04-12', NULL, '2026-04-15 10:54:55'),
(54, 'Repair Depot Demo', '30 Industrial Way', 'BD3 0CC', 53.7905000, -1.7300000, 25000, 0, NULL, 'Asset Group Ltd', 'Inactive', '2026-04-14', NULL, '2026-04-15 10:54:55'),
(55, 'Bradford Retail Ltd', '12 Market Street Bradford', 'BD1 1AA', 53.7958000, -1.7594000, 15000, 0, NULL, NULL, NULL, NULL, 17, '2026-04-15 13:41:19'),
(56, 'Yorkshire Office Group', '45 Leeds Road Bradford', 'BD1 5BJ', 53.8002000, -1.7486000, 22000, 0, NULL, NULL, NULL, NULL, 17, '2026-04-15 13:41:19');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Retail', 'Shops and stores'),
(2, 'Office', 'Office buildings'),
(3, 'Industrial', 'Factories and warehouses'),
(4, 'Vacant', 'Empty properties');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `job_type` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `asset_id`, `job_type`, `notes`, `created_at`) VALUES
(2, 13, 'Complaint', 'cleanliness', '2026-04-02 13:15:38'),
(3, 23, 'Complaint', 'Claning', '2026-04-02 14:25:59');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `raw_bradford`
--

CREATE TABLE `raw_bradford` (
  `col1` text DEFAULT NULL,
  `col2` text DEFAULT NULL,
  `col3` text DEFAULT NULL,
  `col4` text DEFAULT NULL,
  `col5` text DEFAULT NULL,
  `col6` text DEFAULT NULL,
  `col7` text DEFAULT NULL,
  `col8` text DEFAULT NULL,
  `col9` text DEFAULT NULL,
  `col10` text DEFAULT NULL,
  `col11` text DEFAULT NULL,
  `col12` text DEFAULT NULL,
  `col13` text DEFAULT NULL,
  `col14` text DEFAULT NULL,
  `col15` text DEFAULT NULL,
  `col16` text DEFAULT NULL,
  `col17` text DEFAULT NULL,
  `col18` text DEFAULT NULL,
  `col19` text DEFAULT NULL,
  `col20` text DEFAULT NULL,
  `col21` text DEFAULT NULL,
  `col22` text DEFAULT NULL,
  `col23` text DEFAULT NULL,
  `col24` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_bradford`
--

INSERT INTO `raw_bradford` (`col1`, `col2`, `col3`, `col4`, `col5`, `col6`, `col7`, `col8`, `col9`, `col10`, `col11`, `col12`, `col13`, `col14`, `col15`, `col16`, `col17`, `col18`, `col19`, `col20`, `col21`, `col22`, `col23`, `col24`) VALUES
('1', 'A1 Tyres', 'Kensington Street, Keighley, BD21 1PW', 'BD21 1PW', '53.8629', '-1.91625', '4/1/1990', '3900', 'IF3', 'WORKSHOP AND PREMISES', '10/1/2017', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/10/2017', '', '', '', '', '', ' ???-   ', ''),
('2', 'St John The Evangelist Academy', 'St John Rc First School, Beacon Road, Bradford, BD6 3DQ', 'BD6 3DQ', '53.77084', '-1.80146', '4/1/1990', '25250', 'EL', 'SCHOOL AND PREMISES', '10/1/2016', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '1/10/2016', '', '', '', '', '', ' ???2,545.20 ', ''),
('3', 'Kehoe\'S Limited', 'The Venue, Park Lane, Bradford, BD5 0JL', 'BD5 0JL', '53.78453', '-1.75915', '4/1/1990', '6250', 'CL', 'PUBLIC HOUSE AND PREMISES', '4/1/2016', '', 'Empty', 'Empty Charge Retail', '1/7/2016', '', '', '', '', '', '', '', ' ???3,150.00 ', ''),
('4', 'Unit Q', 'Blackshaw Mills, Halifax Road, Bradford, BD6 2HL', 'BD6 2HL', '53.75757', '-1.80099', '4/1/1990', '4250', 'IF3', 'WORKSHOP AND PREMISES', '8/26/2019', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '26/08/2019', '', '', '', '', '', ' ???-   ', ''),
('5', 'Crossflatts Old People Association', 'Community Centre, St Aidans Square, Crossflatts, Bingley, BD16 2BN', 'BD16 2BN', '53.86139', '-1.84458', '4/1/1990', '2800', 'LC', 'COMMUNITY CENTRE AND PREMISES', '4/1/2011', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '1/4/2011', '', '', '', '', '', ' ???282.24 ', ''),
('6', 'Bingley Chamber Of Trade And Commerce', 'Store, Queens Court, Bingley, BD16 2LT', 'BD16 2LT', '53.8485', '-1.83902', '4/1/1990', '1475', 'CW3', 'STORE AND PREMISES', '3/1/2017', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/3/2017', '', '', '', '', '', ' ???-   ', ''),
('7', 'Stables Rear Of', '62, Branksome Drive, Shipley, BD18 4BE', 'BD18 4BE', '53.83643', '-1.81159', '4/1/1990', '900', 'LX', 'STABLES AND PREMISES', '1/3/1992', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2007', '', '', '', '', '', ' ???-   ', ''),
('8', 'Cobley And Cockshott Ltd', '19, Bridge Street, Keighley, BD21 1AA', 'BD21 1AA', '53.86508', '-1.91071', '4/1/1990', '3550', 'CS', 'SHOP AND PREMISES', '8/1/2006', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2007', '', '', '', '', '', ' ???-   ', ''),
('9', 'The Bank', 'Cleasby Road, Menston, Ilkley, LS29 6JE', 'LS29 6JE', '53.89089', '-1.73562', '4/1/1990', '3200', 'CS', 'SHOP AND PREMISES', '12/4/2003', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2007', '', '', '', '', '', ' ???-   ', ''),
('10', 'Santander Uk Plc', 'Abbey National, 9, Nelson Street, Bradford, BD1 5AN', 'BD1 5AN', '53.79037', '-1.75136', '1/14/1999', '985000', 'CO', 'OFFICES AND PREMISES', '1/14/1999', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???594,986.43 ', ''),
('11', 'Bardsley Powell Estates', '4a, Little Horton Green, Bradford, BD5 0NG', 'BD5 0NG', '53.78493', '-1.76503', '4/1/1990', '1400', 'CW3', 'STORE AND PREMISES', '9/1/2007', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???678.17 ', ''),
('12', 'Salem Athletic Cricket Club', 'Sports Ground, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', '53.81357', '-1.79159', '4/1/1990', '5900', 'LS', 'SPORTS GROUND AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', 'Mandatory Sport Relief', '18/09/2005', '', '', '', '', '', ' ???594.72 ', ''),
('13', 'Lalas', '55, Toller Lane, Bradford, BD8 9DD', 'BD8 9DD', '53.80468', '-1.77985', '4/1/1990', '50500', 'CR', '', '12/1/2017', 'Y', 'Occupied', '', '', '', '', '', '', 'Retail Discount', '', '', ' ???16,530.33 ', ''),
('14', 'Empire House Piccadilly Limited', '8-10, Piccadilly, Bradford, BD1 3LS', 'BD1 3LS', '53.79558', '-1.75335', '5/1/1998', '0', 'CO', 'OFFICES AND PREMISES', '11/17/2017', '', 'Empty', 'Exempt Listed Building', '17/11/2017', '', '', '', '', '', '', '', ' ???-   ', ''),
('15', 'Storage', '1st Floor, Drill Parade, Bradford, BD8 7HY', 'BD8 7HY', '53.80294', '-1.7621', '4/1/1992', '0', 'CW3', '', '7/18/2017', '', 'Empty', 'Exempt below RV', '2/6/2018', '', '', '', '', '', '', '', ' ???-   ', ''),
('16', 'Tsb Banking Group Plc', '74-76, Towngate, Keighley, BD21 3QE', 'BD21 3QE', '53.86757', '-1.90727', '4/1/1990', '53000', 'CS1', 'BANK AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???26,712.00 ', ''),
('17', 'Clifton Mill', 'Upper Ground Floor, Clifton Street, Bradford, BD8 7DA', 'BD8 7DA', '53.80571', '-1.76263', '1/30/1995', '8500', 'CW', 'WAREHOUSE AND PREMISES', '11/15/2016', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '15/11/2016', '', '', '', '', '', ' ???-   ', ''),
('18', 'Hbcl Coldstores Limited', 'Unit 9, G B Business Park, Cutler Heights Lane, Bradford, BD4 9HZ', 'BD4 9HZ', '53.78125', '-1.71629', '10/5/1992', '29000', 'CW', 'WAREHOUSE AND PREMISES', '10/29/2004', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???14,239.00 ', ''),
('19', 'Tote Bookmakers Limited', '228, High Street, Wibsey, Bradford, BD6 1QP', 'BD6 1QP', '53.76693', '-1.77439', '4/1/1990', '7600', 'CS', 'SHOP AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???3,731.60 ', ''),
('20', 'The Congregational Federation Limited', '405, Thornton Road, Thornton, Bradford, BD13 3JN', 'BD13 3JN', '53.79046', '-1.85362', '2/17/1997', '4650', 'CS', 'SHOP AND PREMISES', '3/1/2015', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '27/07/2015', '', '', '', '', '', ' ???468.72 ', ''),
('21', 'The Secretary Northcliffe Golf Club', 'Northcliffe Golf Course, High Bank Lane, Shipley, BD18 4LJ', 'BD18 4LJ', '53.82866', '-1.79801', '4/1/1990', '42750', 'LS2', 'GOLF COURSE AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???20,990.25 ', ''),
('22', 'S&M Kirkgate Limited', '6, Piccadilly, Bradford, BD1 3LW', 'BD1 3LW', '53.79515', '-1.75283', '5/1/1998', '12500', 'CO', 'OFFICES AND PREMISES', '12/23/2011', '', 'Empty', 'Exempt Listed Building', '23/12/2011', '', '', '', '', '', '', '', ' ???-   ', ''),
('23', 'Mahmoods (Franchising) Limited', 'Unit 2, Red Oak House, Duncombe Street, Bradford, BD8 9AJ', 'BD8 9AJ', '53.79679', '-1.78167', '7/3/1993', '18500', 'CW', 'WAREHOUSE AND PREMISES', '6/1/2016', '', 'Empty', 'Exempt not Relevent Hereditament', '9/5/2017', '', '', '', '', '', '', '', ' ???-   ', ''),
('24', 'Penyffordd Pharmacy Limited', '238, Whetley Lane, Bradford, BD8 9DJ', 'BD8 9DJ', '53.80341', '-1.77624', '4/1/1990', '6600', 'CS', 'PHARMACY AND PREMISES', '6/30/2006', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/7/2012', '', '', '', '', '', ' ???-   ', ''),
('25', 'The Upstagers Theatre Charity Limited', 'Unit 6, 1st Floor, Booths Yard, Nile Road, Ilkley, LS29 8HJ', 'LS29 8HJ', '53.92581', '-1.82178', '4/1/1990', '4750', 'IF3', 'WORKSHOP AND PREMISES', '8/10/2010', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '10/8/2010', '', '', '', '', '', ' ???478.80 ', ''),
('26', 'Primesight Limited', 'Advert Rights No 1344 02-06, Baildon Bridge, Otley Road, Baildon, BD17 7ER', 'BD17 7ER', '53.83815', '-1.77241', '4/1/1990', '8000', 'CA', 'ADVERTISING RIGHT AND PREMISES', '9/1/2009', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???3,928.00 ', ''),
('27', 'Lodge Of The Three Graces No 408', 'Masonic Hall Opp, Police Station, Mill Hey, Haworth, Keighley, BD22 8NA', 'BD22 8NA', '53.83236', '-1.94672', '4/1/1990', '5900', 'CL2', 'CLUB AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2007', '', '', '', '', '', ' ???-   ', ''),
('28', 'Co-Operative Group Limited', 'Shop, 24, Station Road, Oxenhope, Keighley, BD22 9JJ', 'BD22 9JJ', '53.811', '-1.95092', '4/1/1990', '27000', 'CS', '', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???13,257.00 ', ''),
('29', 'Raiseprint Limited', 'Unit E1-2, Royd Ings Avenue, Keighley, BD21 3QY', 'BD21 3QY', '53.86607', '-1.9072', '4/1/1990', '42750', 'IF', '', '8/22/1995', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???20,990.25 ', ''),
('30', 'Edwick Memorial Hall Trust Limited', 'The Birches, Otley Road, Eldwick, Bingley, BD16 3EQ', 'BD16 3EQ', '53.86029', '-1.81275', '4/1/1990', '4300', 'CL', 'PUBLIC HOUSE AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '1/4/1998', '', '', 'Retail Discount', '', '', ' ???288.96 ', ''),
('31', 'The Childrens Place Limited', 'Creche, 83, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', '53.81357', '-1.79159', '6/10/1998', '16500', 'EN1', 'DAY NURSERY AND PREMISES', '1/1/2013', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???8,101.50 ', ''),
('32', 'Empire House Piccadilly Limited', '3rd Floor, 8-10, Piccadilly, Bradford, BD1 3LS', 'BD1 3LS', '53.79558', '-1.75335', '5/1/1998', '18500', 'CO', 'OFFICES AND PREMISES', '11/16/2017', '', 'Empty', 'Exempt Listed Building', '16/11/2017', '', '', '', '', '', '', '', ' ???-   ', ''),
('33', 'Sofa Doctor Ltd', '103, Legrams Lane, Bradford, BD7 2AA', 'BD7 2AA', '53.79117', '-1.77907', '4/1/1990', '5600', 'CS', '', '4/6/2018', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '6/4/2018', '', '', '', '', '', ' ???-   ', ''),
('34', 'Co-Operative Group Limited', '6, Tyrrel Street, Bradford, BD1 1RJ', 'BD1 1RJ', '53.79385', '-1.75364', '4/1/1990', '31000', 'CS1', '', '3/17/1992', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???15,221.00 ', ''),
('35', 'Car Parking Bay', 'No 19, West Riding House, Cheapside, Bradford, BD1 4HR', 'BD1 4HR', '53.79561', '-1.75257', '4/1/1990', '600', 'CP1', 'CAR PARKING SPACE AND PREMISES', '4/1/2009', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???294.60 ', ''),
('36', 'Warehouse And Premises', 'Worth Way, Keighley, BD21 5AJ', 'BD21 5AJ', '53.86523', '-1.90619', '4/1/1990', '17250', 'CS7', 'SHOWROOM AND PREMISES', '2/18/2012', 'Y', 'Occupied', '', '', '', '', '', '', 'Retail Discount', '', '', ' ???5,646.50 ', ''),
('37', 'Shorts Industries Limited', '6, Station Road, Canal Rd-Queens Rd, Bradford, BD1 4SF', 'BD1 4SF', '53.80903', '-1.75737', '1/3/1995', '71000', 'IF3', '', '3/8/2019', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???24,833.70 ', ''),
('38', 'Babycare (Bradford) Limited', 'Unit 1, Oxford Works, Dudley Hill Road, Bradford, BD2 3AA', 'BD2 3AA', '53.80949', '-1.73029', '4/1/1990', '11250', 'CW3', 'STORE AND PREMISES', '4/1/2009', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???5,523.75 ', ''),
('39', 'The Secretary Keighley Golf Club', 'Keighley Golf Club, Howden Park, Silsden, BD20 6DH', 'BD20 6DH', '53.88768', '-1.91658', '4/1/1990', '57000', 'LS2', '', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???28,728.00 ', ''),
('40', 'Bellissimo Workspace Limited', 'Unit 31, Dalton Mills, Dalton Lane, Keighley, BD21 4JH', 'BD21 4JH', '53.86922', '-1.89439', '8/15/1995', '1350', 'CO', 'OFFICES AND PREMISES', '5/15/2013', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2014', '', '', '', '', '', ' ???-   ', ''),
('41', 'Mectec', 'Ingrow Bridge, South Street, Keighley, BD21 5AX', 'BD21 5AX', '53.85454', '-1.91573', '4/1/1990', '7600', 'IF3', 'WORKSHOP AND PREMISES', '2/25/1995', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2007', '', '', '', '', '', ' ???-   ', ''),
('42', 'Keighley & Worth Valley Railway Preservation Society Limited', 'Keighley And, Worth Valley Railway, Station Road, Haworth, Keighley, BD22 8NJ', 'BD22 8NJ', '53.83122', '-1.94873', '4/1/1990', '100000', 'LX', 'HERITAGE RAILWAY AND PREMISES', '4/1/1990', 'Y', 'Occupied', '', '', 'Mandatory Charity Relief', '13/07/2010', '', '', '', '', '', ' ???8,181.39 ', ''),
('43', 'Tunnacliffe & Lambert Limited', '18, Station Road, Clayton, Bradford, BD14 6JA', 'BD14 6JA', '53.78154', '-1.81826', '4/1/1990', '6000', 'CS', '', '10/1/2015', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???2,228.27 ', ''),
('44', 'Medical Centre', '81, Leylands Lane, Bradford, BD9 5QT', 'BD9 5QT', '53.81357', '-1.79159', '5/15/1998', '45000', 'MH', 'SURGERY AND PREMISES', '5/15/1998', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???22,095.00 ', ''),
('45', 'The Governing Body', 'Sandy Lane Primary School, Cottingley Road, Bradford, BD15 9JU', 'BD15 9JU', '53.81695', '-1.83194', '4/1/1990', '48000', 'EL', '', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???23,568.00 ', ''),
('46', 'Priestley & Webb Ltd', '318, Keighley Road, Bradford, BD9 4EX', 'BD9 4EX', '53.82016', '-1.77448', '4/1/1990', '5000', 'CS', 'SHOP AND PREMISES', '9/15/2015', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '15/09/2015', '', '', '', '', '', ' ???-   ', ''),
('47', 'Central Motor Company', '129, Great Horton Road, Bradford, BD7 1QG', 'BD7 1QG', '53.78813', '-1.76987', '4/11/1994', '14000', 'CX', 'LAND USED FOR DISPLAY AND PREMISES', '4/1/2019', 'Y', 'Occupied', '', '', 'Small Business Rates Relief', '1/4/2019', '', '', 'Retail Discount', '', '', ' ???3,055.11 ', ''),
('48', 'Myers Building Supplies Ltd', 'Old Cornmill, Keighley Road, Silsden, BD20 0DY', 'BD20 0DY', '53.91028', '-1.93852', '4/1/1990', '54000', 'CW', '', '4/1/1990', 'Y', 'Occupied', '', '', '', '', '', '', '', '', '', ' ???26,366.62 ', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(20) NOT NULL DEFAULT 'user',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `role`, `is_verified`, `verification_token`) VALUES
(4, 'sulaiman', 'sulaiman@gmail.com', '$2b$10$edVx6PPN2ZNV5CTugerRd.qKc2yJvHIwcu8dZ8YT8BHgj5u0LcHa.', '2026-04-02 13:08:12', 'user', 0, NULL),
(16, 'abdul', 'qadeera040@gmail.com', '$2b$10$7Dekm/drZIVUaYvIwx11Nuyix4McXQxoJWi/Nz5dEb917vZA0GWDe', '2026-04-15 10:02:44', 'admin', 1, NULL),
(18, 'aadam', 'aadamiqbal05@gmail.com', '$2b$10$XrlqDf8Ww/ceojL16pXOVevWN43od5yPbkv41oB70IsGtGG1dbVw2', '2026-04-16 13:28:58', 'user', 0, NULL),
(22, 'hassan', 'raqadeer@bradford.ac.uk', '$2b$10$D0PbUOh.LT31iwcSsV0kWu11SmeNDXN7/WKDMHAegiyAxCLe2MKba', '2026-04-16 14:21:55', 'user', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
