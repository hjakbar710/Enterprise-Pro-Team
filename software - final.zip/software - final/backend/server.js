const express = require("express");
const path = require("path");
const session = require("express-session");

const assetsRoute = require("./routes/assets");
const authRoutes = require("./routes/auth");
const uploadRoute = require("./routes/upload");
const adminRoute = require("./routes/admin");

const app = express();

app.use(express.json());

app.use(session({
  secret: "secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true
  }
}));

app.use("/assets", assetsRoute);
app.use("/auth", authRoutes);
app.use("/upload", uploadRoute);
app.use("/admin", adminRoute);

app.use(express.static(path.join(__dirname, "../frontend")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/login.html"));
});

const PORT = 3000;

app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});