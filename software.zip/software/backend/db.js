// Import the MySQL2 library which allows Node.js to communicate with a MySQL database
const mysql = require("mysql2");

// Create a database connection using MySQL credentials
const db = mysql.createConnection({

  // The database server location (localhost means the database is on the same computer)
  host: "localhost",

  // MySQL username (default for local development is usually "root")
  user: "root",

  // Password for the MySQL user (empty here for local development)
  password: "",

  // Name of the database the application will use
  database: "spatial_portal"

});

// Attempt to connect to the MySQL database
db.connect(err => {

  // If an error occurs during connection
  if(err){

    // Print error message in the server console
    console.error("Database connection failed:", err);

    // Stop further execution
    return;

  }

  // If connection is successful
  console.log("Connected to MySQL");

});

// Export the database connection so other files (routes, server, etc.) can use it
module.exports = db;