// Import Express framework to build the web server and API
const express = require("express");

// Import path module to safely work with file and directory paths
const path = require("path");

// Import express-session to manage user login sessions
const session = require("express-session");

// Import route files that contain API endpoints
const assetsRoute = require("./routes/assets");
const authRoutes = require("./routes/auth");

// Create the Express application
const app = express();


// -----------------------------
// MIDDLEWARE
// -----------------------------

// Enable Express to automatically parse JSON data sent in requests
app.use(express.json());


// -----------------------------
// SESSION CONFIGURATION
// -----------------------------
// This middleware enables session-based authentication.
// It stores login information so users stay logged in between requests.
app.use(session({

  // Secret key used to sign session cookies
  secret: "secret-key",

  // Prevent session from being saved if it was not modified
  resave: false,

  // Prevent empty sessions from being stored
  saveUninitialized: false,

  // Session cookie configuration
  cookie: {

    // Makes the cookie inaccessible to client-side JavaScript for security
    httpOnly: true

  }

}));


// -----------------------------
// API ROUTES
// -----------------------------

// Routes for asset-related operations (view assets, add assets, log jobs)
app.use("/assets", assetsRoute);

// Routes for authentication (register, login, logout, session check)
app.use("/auth", authRoutes);


// -----------------------------
// STATIC FILE SERVING
// -----------------------------
// Serve all files from the frontend folder (HTML, CSS, JS).
// This allows the browser to access pages like index.html and login.html.
app.use(express.static(path.join(__dirname, "../frontend")));


// -----------------------------
// DEFAULT ROUTE
// -----------------------------
// When the root URL (/) is visited, load the login page.
app.get("/", (req, res) => {

  res.sendFile(path.join(__dirname, "../frontend/login.html"));

});


// -----------------------------
// START SERVER
// -----------------------------

// Define the port the server will run on
const PORT = 3000;

// Start the Express server and listen for incoming requests
app.listen(PORT, () => {

  console.log("Server running on port " + PORT);

});