// Import Express framework to create API routes
const express = require("express");

// Import the database connection pool
// This is used to send SQL queries to the database
const pool = require("../db");

// Create a router object to define category routes
const router = express.Router();


// -----------------------------
// GET ALL CATEGORIES
// -----------------------------
// This route retrieves all categories from the database.
// Categories are sorted alphabetically by their name.
router.get("/", async (req, res) => {

  // Execute SQL query to select all categories
  const result = await pool.query("SELECT * FROM categories ORDER BY name");

  // Return the category data as JSON
  res.json(result.rows);

});


// -----------------------------
// ADD NEW CATEGORY
// -----------------------------
// This route allows users to create a new category.
router.post("/", async (req, res) => {

  // Extract category information from the request body
  const { name, description } = req.body;

  // SQL query to insert a new category into the database
  const result = await pool.query(
    "INSERT INTO categories (name, description) VALUES ($1, $2) RETURNING *",
    [name, description]
  );

  // Return the newly created category as JSON
  res.json(result.rows[0]);

});


// Export the router so it can be used in server.js
module.exports = router;