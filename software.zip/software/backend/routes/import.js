// Import Express framework to create API routes
const express = require("express");

// Import Multer to handle file uploads (used for uploading CSV files)
const multer = require("multer");

// Import csv-parser to read and parse CSV file contents
const csv = require("csv-parser");

// Import file system module to read and delete files
const fs = require("fs");

// Import database connection pool
const pool = require("../db");

// Create a router object to define routes
const router = express.Router();

// Configure Multer to store uploaded files in the "uploads" folder
const upload = multer({ dest: "uploads/" });


// -----------------------------
// IMPORT CSV DATA
// -----------------------------
// This route allows a CSV file to be uploaded and imported into the database.
router.post("/", upload.single("file"), async (req, res) => {

  // Create an array to temporarily store rows from the CSV
  const rows = [];

  // Read the uploaded CSV file
  fs.createReadStream(req.file.path)

    // Pipe the file data into the CSV parser
    .pipe(csv())

    // For every row in the CSV file
    .on("data", (row) => {

      // Store the row in the rows array
      rows.push(row);

    })

    // When the file has finished being read
    .on("end", async () => {

      try {

        // Loop through every row in the CSV file
        for (const row of rows) {

          // Extract postcode from CSV (handles different capitalisations)
          const postcode = row.Postcode || row.postcode || null;

          // Convert latitude value from string to number
          const latitude = parseFloat(row.Latitude || row.latitude);

          // Convert longitude value from string to number
          const longitude = parseFloat(row.Longitude || row.longitude);

          // Extract ward name if available
          const ward = row.Ward || row.ward || null;

          // Set council area (fixed value for this dataset)
          const council_area = "Bradford";

          // Only insert the row if valid coordinates exist
          if (!isNaN(latitude) && !isNaN(longitude)) {

            // Insert the data into the assets table
            await pool.query(
              `INSERT INTO assets (postcode, latitude, longitude, ward, council_area)
               VALUES ($1, $2, $3, $4, $5)`,
              [postcode, latitude, longitude, ward, council_area]
            );

          }
        }

        // Delete the uploaded CSV file after processing
        fs.unlinkSync(req.file.path);

        // Send success response
        res.json({ message: "CSV imported successfully" });

      } catch (error) {

        // If any error occurs during processing
        res.status(500).json({ error: error.message });

      }
    });
});


// Export the router so it can be used in server.js
module.exports = router;