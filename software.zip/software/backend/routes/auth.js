// Import Express framework to create API routes
const express = require("express")

// Import bcrypt for hashing and comparing passwords securely
const bcrypt = require("bcrypt")

// Import database connection
const db = require("../db")

// Create a router object to define authentication routes
const router = express.Router()


// -----------------------------
// USER REGISTRATION
// -----------------------------
// This route allows a new user to register an account.
router.post("/register", async (req,res)=>{

// Extract user information from the request body
const {username,email,password} = req.body

// Hash the password using bcrypt to securely store it
const hashedPassword = await bcrypt.hash(password,10)

// SQL query to insert a new user into the database
const sql = `
INSERT INTO users (username,email,password)
VALUES (?,?,?)
`

// Execute the query
db.query(sql,[username,email,hashedPassword],(err,result)=>{

// If a database error occurs
if(err){
console.error(err)
res.status(500).send("Registration failed")
return
}

// Send confirmation response
res.json({message:"User registered"})

})

})



// -----------------------------
// USER LOGIN
// -----------------------------
// This route authenticates users when they log in.
router.post("/login",(req,res)=>{

// Extract username and password from request body
const {username,password} = req.body

// SQL query to retrieve the user from the database
const sql = "SELECT * FROM users WHERE username = ?"

// Execute the query
db.query(sql,[username],async(err,results)=>{

// Handle database error
if(err){
res.status(500).send("Login failed")
return
}

// If no user is found with the given username
if(results.length === 0){
res.status(401).send("User not found")
return
}

// Get the first matching user record
const user = results[0]

// Compare the entered password with the hashed password in the database
const match = await bcrypt.compare(password,user.password)

// If passwords do not match
if(!match){
res.status(401).send("Incorrect password")
return
}

// Save the user ID in the session to mark the user as logged in
req.session.userId = user.id

// Save the session and send login confirmation
req.session.save(()=>{
res.json({message:"Login successful"})
})

})

})



// -----------------------------
// CHECK LOGIN SESSION
// -----------------------------
// This route checks if a user is currently logged in.
router.get("/check",(req,res)=>{

// If a session userId exists, the user is logged in
if(req.session.userId){
res.json({loggedIn:true})
}else{
// Otherwise return unauthorized response
res.status(401).json({loggedIn:false})
}

})



// -----------------------------
// LOGOUT USER
// -----------------------------
// This route logs the user out by destroying the session.
router.get("/logout",(req,res)=>{

// Destroy the session
req.session.destroy(()=>{

// Send confirmation response
res.json({message:"Logged out"})

})

})


// Export router so it can be used in server.js
module.exports = router