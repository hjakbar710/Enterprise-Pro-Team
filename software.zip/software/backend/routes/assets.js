// Import Express framework
const express = require("express");

// Import database connection file (MySQL connection)
const db = require("../db");

// Create a router object so we can define routes in this file
const router = express.Router();


// -----------------------------
// Authentication Middleware
// -----------------------------
// This function checks if the user is logged in.
// If there is no session userId, the request is rejected.
function requireLogin(req,res,next){

// If the session does not contain a userId, user is not logged in
if(!req.session.userId){
return res.status(401).send("Not logged in")
}

// If logged in, allow the request to continue
next()

}



// -----------------------------
// GET ALL ASSETS
// -----------------------------
// This route returns all assets from the database.
// It also joins the categories table so we can display category names.
router.get("/", requireLogin, (req,res)=>{

// SQL query to retrieve asset information
const sql = `
SELECT
assets.id,
ratepayer,
address,
postcode,
latitude,
longitude,
rateable_value,
job_count,
categories.name AS category
FROM assets
LEFT JOIN categories
ON assets.category_id = categories.id
`

// Execute query
db.query(sql,(err,results)=>{

// If database error occurs
if(err){
console.error(err)
res.status(500).send("Database error")
return
}

// Return the asset data as JSON
res.json(results)

})

})



// -----------------------------
// ADD NEW ASSET
// -----------------------------
// This route allows users to add a new asset to the system.
router.post("/", requireLogin, (req,res)=>{

// Extract asset details from the request body
const {
ratepayer,
address,
postcode,
latitude,
longitude,
rateable_value
} = req.body

// SQL query to insert a new asset
const sql = `
INSERT INTO assets
(ratepayer,address,postcode,latitude,longitude,rateable_value)
VALUES (?,?,?,?,?,?)
`

// Execute database query
db.query(sql,
[ratepayer,address,postcode,latitude,longitude,rateable_value],
(err,result)=>{

// Handle database error
if(err){
console.error(err)
res.status(500).send("Insert failed")
return
}

// Return confirmation and new asset ID
res.json({
message:"Asset added",
id:result.insertId
})

})

})



// -----------------------------
// LOG JOB AGAINST ASSET
// -----------------------------
// This route allows users to log a job for a specific asset.
router.post("/:id/job", requireLogin, (req,res)=>{

// Get the asset ID from the URL parameter
const assetId = req.params.id

// Get job details from request body
const {job_type,notes} = req.body

// SQL query to insert job record
const sql = `
INSERT INTO jobs (asset_id,job_type,notes)
VALUES (?,?,?)
`

// Execute job insertion
db.query(sql,[assetId,job_type,notes],(err,result)=>{

// Handle database error
if(err){
console.error(err)
res.status(500).send("Job insert failed")
return
}


// SQL query to update the job count in the assets table
const updateSql = `
UPDATE assets
SET job_count = job_count + 1
WHERE id = ?
`

// Execute update query
db.query(updateSql,[assetId])

// Send confirmation response
res.json({message:"Job logged"})

})

})


// Export the router so it can be used in server.js
module.exports = router